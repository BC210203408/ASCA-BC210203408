import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class UserDetailsRecord extends FirestoreRecord {
  UserDetailsRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "Name" field.
  String? _name;
  String get name => _name ?? '';
  bool hasName() => _name != null;

  // "Gender" field.
  String? _gender;
  String get gender => _gender ?? '';
  bool hasGender() => _gender != null;

  // "Height" field.
  String? _height;
  String get height => _height ?? '';
  bool hasHeight() => _height != null;

  // "Bio" field.
  String? _bio;
  String get bio => _bio ?? '';
  bool hasBio() => _bio != null;

  // "Image" field.
  String? _image;
  String get image => _image ?? '';
  bool hasImage() => _image != null;

  // "Age" field.
  String? _age;
  String get age => _age ?? '';
  bool hasAge() => _age != null;

  // "Task" field.
  String? _task;
  String get task => _task ?? '';
  bool hasTask() => _task != null;

  // "DueDate" field.
  String? _dueDate;
  String get dueDate => _dueDate ?? '';
  bool hasDueDate() => _dueDate != null;

  void _initializeFields() {
    _name = snapshotData['Name'] as String?;
    _gender = snapshotData['Gender'] as String?;
    _height = snapshotData['Height'] as String?;
    _bio = snapshotData['Bio'] as String?;
    _image = snapshotData['Image'] as String?;
    _age = snapshotData['Age'] as String?;
    _task = snapshotData['Task'] as String?;
    _dueDate = snapshotData['DueDate'] as String?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('UserDetails');

  static Stream<UserDetailsRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => UserDetailsRecord.fromSnapshot(s));

  static Future<UserDetailsRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => UserDetailsRecord.fromSnapshot(s));

  static UserDetailsRecord fromSnapshot(DocumentSnapshot snapshot) =>
      UserDetailsRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static UserDetailsRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      UserDetailsRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'UserDetailsRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is UserDetailsRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createUserDetailsRecordData({
  String? name,
  String? gender,
  String? height,
  String? bio,
  String? image,
  String? age,
  String? task,
  String? dueDate,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'Name': name,
      'Gender': gender,
      'Height': height,
      'Bio': bio,
      'Image': image,
      'Age': age,
      'Task': task,
      'DueDate': dueDate,
    }.withoutNulls,
  );

  return firestoreData;
}

class UserDetailsRecordDocumentEquality implements Equality<UserDetailsRecord> {
  const UserDetailsRecordDocumentEquality();

  @override
  bool equals(UserDetailsRecord? e1, UserDetailsRecord? e2) {
    return e1?.name == e2?.name &&
        e1?.gender == e2?.gender &&
        e1?.height == e2?.height &&
        e1?.bio == e2?.bio &&
        e1?.image == e2?.image &&
        e1?.age == e2?.age &&
        e1?.task == e2?.task &&
        e1?.dueDate == e2?.dueDate;
  }

  @override
  int hash(UserDetailsRecord? e) => const ListEquality().hash([
        e?.name,
        e?.gender,
        e?.height,
        e?.bio,
        e?.image,
        e?.age,
        e?.task,
        e?.dueDate
      ]);

  @override
  bool isValidKey(Object? o) => o is UserDetailsRecord;
}
