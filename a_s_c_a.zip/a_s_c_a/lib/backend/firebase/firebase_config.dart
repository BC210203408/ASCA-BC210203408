import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

Future initFirebase() async {
  if (kIsWeb) {
    await Firebase.initializeApp(
        options: FirebaseOptions(
            apiKey: "AIzaSyCjhNstkicXSw0br3GAN8qOKVxLswTQ5gA",
            authDomain: "asca-e34ed.firebaseapp.com",
            projectId: "asca-e34ed",
            storageBucket: "asca-e34ed.appspot.com",
            messagingSenderId: "527527013265",
            appId: "1:527527013265:web:61fdff60364fd6058b4830"));
  } else {
    await Firebase.initializeApp();
  }
}
