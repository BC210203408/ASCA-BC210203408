package com.mycompany.asca

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
