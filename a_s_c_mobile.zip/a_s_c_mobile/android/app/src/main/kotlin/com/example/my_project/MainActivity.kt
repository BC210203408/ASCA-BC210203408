package com.mycompany.ascmobile

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
