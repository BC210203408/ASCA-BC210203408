import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/flutter_flow/flutter_flow_youtube_player.dart';
import 'breathing_space_meditation_widget.dart'
    show BreathingSpaceMeditationWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class BreathingSpaceMeditationModel
    extends FlutterFlowModel<BreathingSpaceMeditationWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
