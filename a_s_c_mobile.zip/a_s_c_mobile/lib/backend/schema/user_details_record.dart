import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class UserDetailsRecord extends FirestoreRecord {
  UserDetailsRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "UserName" field.
  String? _userName;
  String get userName => _userName ?? '';
  bool hasUserName() => _userName != null;

  // "UserAge" field.
  int? _userAge;
  int get userAge => _userAge ?? 0;
  bool hasUserAge() => _userAge != null;

  // "UserHeight" field.
  int? _userHeight;
  int get userHeight => _userHeight ?? 0;
  bool hasUserHeight() => _userHeight != null;

  // "UserWeight" field.
  int? _userWeight;
  int get userWeight => _userWeight ?? 0;
  bool hasUserWeight() => _userWeight != null;

  // "UserImage" field.
  String? _userImage;
  String get userImage => _userImage ?? '';
  bool hasUserImage() => _userImage != null;

  // "UserHistory" field.
  String? _userHistory;
  String get userHistory => _userHistory ?? '';
  bool hasUserHistory() => _userHistory != null;

  void _initializeFields() {
    _userName = snapshotData['UserName'] as String?;
    _userAge = castToType<int>(snapshotData['UserAge']);
    _userHeight = castToType<int>(snapshotData['UserHeight']);
    _userWeight = castToType<int>(snapshotData['UserWeight']);
    _userImage = snapshotData['UserImage'] as String?;
    _userHistory = snapshotData['UserHistory'] as String?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('User_Details');

  static Stream<UserDetailsRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => UserDetailsRecord.fromSnapshot(s));

  static Future<UserDetailsRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => UserDetailsRecord.fromSnapshot(s));

  static UserDetailsRecord fromSnapshot(DocumentSnapshot snapshot) =>
      UserDetailsRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static UserDetailsRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      UserDetailsRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'UserDetailsRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is UserDetailsRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createUserDetailsRecordData({
  String? userName,
  int? userAge,
  int? userHeight,
  int? userWeight,
  String? userImage,
  String? userHistory,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'UserName': userName,
      'UserAge': userAge,
      'UserHeight': userHeight,
      'UserWeight': userWeight,
      'UserImage': userImage,
      'UserHistory': userHistory,
    }.withoutNulls,
  );

  return firestoreData;
}

class UserDetailsRecordDocumentEquality implements Equality<UserDetailsRecord> {
  const UserDetailsRecordDocumentEquality();

  @override
  bool equals(UserDetailsRecord? e1, UserDetailsRecord? e2) {
    return e1?.userName == e2?.userName &&
        e1?.userAge == e2?.userAge &&
        e1?.userHeight == e2?.userHeight &&
        e1?.userWeight == e2?.userWeight &&
        e1?.userImage == e2?.userImage &&
        e1?.userHistory == e2?.userHistory;
  }

  @override
  int hash(UserDetailsRecord? e) => const ListEquality().hash([
        e?.userName,
        e?.userAge,
        e?.userHeight,
        e?.userWeight,
        e?.userImage,
        e?.userHistory
      ]);

  @override
  bool isValidKey(Object? o) => o is UserDetailsRecord;
}
