import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

Future initFirebase() async {
  if (kIsWeb) {
    await Firebase.initializeApp(
        options: FirebaseOptions(
            apiKey: "AIzaSyAFJEWPnDqpoVhSo4BrzZmTsbA-_ZL0_JU",
            authDomain: "a-s-c-mobile-w2qllz.firebaseapp.com",
            projectId: "a-s-c-mobile-w2qllz",
            storageBucket: "a-s-c-mobile-w2qllz.appspot.com",
            messagingSenderId: "144501533847",
            appId: "1:144501533847:web:771d7f7f395c51c93b4dd2"));
  } else {
    await Firebase.initializeApp();
  }
}
