import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/backend/firebase_storage/storage.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/flutter_flow/upload_data.dart';
import 'profile_page_widget.dart' show ProfilePageWidget;
import 'package:cached_network_image/cached_network_image.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:easy_debounce/easy_debounce.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class ProfilePageModel extends FlutterFlowModel<ProfilePageWidget> {
  ///  State fields for stateful widgets in this page.

  bool isDataUploading1 = false;
  FFUploadedFile uploadedLocalFile1 =
      FFUploadedFile(bytes: Uint8List.fromList([]));
  String uploadedFileUrl1 = '';

  bool isDataUploading2 = false;
  FFUploadedFile uploadedLocalFile2 =
      FFUploadedFile(bytes: Uint8List.fromList([]));
  String uploadedFileUrl2 = '';

  // State field(s) for UserName widget.
  FocusNode? userNameFocusNode;
  TextEditingController? userNameTextController;
  String? Function(BuildContext, String?)? userNameTextControllerValidator;
  // State field(s) for UserAge widget.
  FocusNode? userAgeFocusNode;
  TextEditingController? userAgeTextController;
  String? Function(BuildContext, String?)? userAgeTextControllerValidator;
  // State field(s) for UserHeight widget.
  FocusNode? userHeightFocusNode;
  TextEditingController? userHeightTextController;
  String? Function(BuildContext, String?)? userHeightTextControllerValidator;
  // State field(s) for UserWeight widget.
  FocusNode? userWeightFocusNode;
  TextEditingController? userWeightTextController;
  String? Function(BuildContext, String?)? userWeightTextControllerValidator;
  // State field(s) for UserHistory widget.
  FocusNode? userHistoryFocusNode;
  TextEditingController? userHistoryTextController;
  String? Function(BuildContext, String?)? userHistoryTextControllerValidator;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    userNameFocusNode?.dispose();
    userNameTextController?.dispose();

    userAgeFocusNode?.dispose();
    userAgeTextController?.dispose();

    userHeightFocusNode?.dispose();
    userHeightTextController?.dispose();

    userWeightFocusNode?.dispose();
    userWeightTextController?.dispose();

    userHistoryFocusNode?.dispose();
    userHistoryTextController?.dispose();
  }
}
